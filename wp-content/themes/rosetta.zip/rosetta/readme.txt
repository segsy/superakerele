Theme Name: Rosetta
Theme URI: https://www.flatlayers.com/themes/rosetta
Author: FlatLayers
Author URI: https://www.flatlayers.com
Description: Minimalist & Typography Based WordPress Blog Theme
Version: 1.5
Tested up to: 6.1
Requires PHP: 5.6
License: GNU/GPL Version 2 or later.
License URI: http://www.gnu.org/licenses/gpl.html
Documentation: https://www.flatlayers.com/docs/tulip/
