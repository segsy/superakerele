<?php
/*
Plugin Name: Rosetta Theme Addons
Plugin URI: https://flatlayers.com
Description: Rosetta theme addons (Widgets, Sharing Icons, Author Social Profiles).
Version: 1.0
Author: FlatLayers
Author URI: https://flatlayers.com
*/


if (!defined('FL_ROSETTA_ADDONS_VERSION')) {

	define('FL_ROSETTA_ADDONS_VERSION', '1.0');

	function fl_rosetta_addons_base_url() {
		return trailingslashit(apply_filters('fl_rosetta_addons_base_url', plugins_url('', __FILE__)));
	}

	function fl_rosetta_addons_init() {
	    load_plugin_textdomain( 'flatlayers', false, fl_rosetta_addons_base_url() . '/languages' ); 
	}
	add_action( 'plugins_loaded', 'fl_rosetta_addons_init' );

	// User Socials
	include_once( 'addons/user-socials.php' );

	// Sharing
	include_once( 'addons/sharing.php' );

	// Widgets
	include_once( 'addons/widgets/latest-posts.php');
	include_once( 'addons/widgets/category-posts.php' );
	include_once( 'addons/widgets/ids-posts.php' );
	include_once( 'addons/widgets/random-posts.php' );
	include_once( 'addons/widgets/about.php');


} // end defined check
