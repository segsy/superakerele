<?php
/*
 * FLatLayers Random Posts Widget
 */

class FL_Rosetta_Random_Posts extends WP_Widget {
	
	public function __construct() {        
        $widget_ops = array( 'classname' => 'fl-letterbox', 'description' => 'Custom Random Posts Widget' );
        parent::__construct(
            'FL_Rosetta_Random_Posts',  // Base ID
            FLATLAYERS_THEME_NAME.' Random Posts', // Name
            $widget_ops
        );
		
	}
	
	/**
	 * Front-end display of widget
	**/
	public function widget( $args, $instance ) {
		extract($args);
		$title = apply_filters('widget_title', $instance['title']);
		$posts_num = isset( $instance['posts_num'] ) ? $instance['posts_num'] : '3';
		
		$loop = new WP_Query(
			array(
				'post_type' => 'post',
				'post_status' => 'publish',
				'orderby' => 'rand',
				'posts_per_page' => $posts_num,
				'ignore_sticky_posts' => 1
			)
		);
		
        if ( $loop->have_posts() ) {

			echo ( $args['before_widget'] );

            if (!empty($title) ) {
	            echo ( $args['before_title'] . $title . $args['after_title'] );
	        }

			while ( $loop->have_posts() ) {
            	$loop->the_post();

				$thumbs = true;
				$class = '';

				// Hide Thumbnails
				if ( get_theme_mod('hide_thumbs') ) { $thumbs = false; }

				if ( has_post_thumbnail() && $thumbs == true ) {
				    $class = 'img-bg';
				}

				?>
				<article class="fl-post <?php echo $class; ?>">					
					<span class="letter"><?php echo esc_html( mb_substr(get_the_title(), 0, 1, "UTF-8") ); ?></span>

					<div class="post-header">
				        <h4 class="title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4> 
				        <div class="meta-wrap">
				        	<div class="fl-category"><?php echo the_category(' '); ?></div>
				            <div class="fl-meta">
				                <?php if ( !get_theme_mod( 'hide_meta_date' ) ) { ?>
				                <span class="meta date"><?php echo get_the_date(); ?></span>
				                <?php } ?>
				            </div>
				        </div>
				    </div>

                    <?php if ( has_post_thumbnail() && $thumbs == true ) { ?>
				        <div class="fl-picture">
			                <?php
			                the_post_thumbnail('rosetta_medium');
			                ?>
				        </div>
				    <?php } ?>
	           	</article>

            <?php }

            echo ( $args['after_widget'] );

			wp_reset_postdata();    
		}
		
	}	
	
	/**
     * Back-end widget form.
     */
    public function form( $instance ) {
        $instance = wp_parse_args( (array) $instance, array( 
			'title'      => '',
			'posts_num'  => '3',
		) );
		?>
		<p>
	        <label for="<?php echo esc_attr( $this->get_field_id('title') ); ?>"><?php echo esc_html_e( 'Title:', 'flatlayers' ); ?></label><br>
	        <input class="widefat" id="<?php echo esc_attr( $this->get_field_id('title') ); ?>" name="<?php echo esc_attr( $this->get_field_name('title') ); ?>" type="text" value="<?php echo esc_attr( $instance['title'] ); ?>">
	    </p>
		<p>
	        <label for="<?php echo esc_attr( $this->get_field_id('posts_num') ); ?>"><?php echo esc_html_e( 'Number of Posts:', 'flatlayers'); ?></label><br>
	        <input class="widefat" id="<?php echo esc_attr( $this->get_field_id('posts_num') ); ?>" name="<?php echo esc_attr( $this->get_field_name('posts_num') ); ?>" type="number" value="<?php echo esc_attr( $instance['posts_num'] ); ?>">
	    </p>
		<?php
	}

	/**
     * Sanitize widget form values as they are saved.
     */
    public function update( $new_instance, $old_instance ) {
        $instance = $old_instance;
        
        $instance['title'] = strip_tags( $new_instance['title'] );
        $instance['posts_num']  = $new_instance['posts_num'];

        return $instance;
    }
    
}

// register widget
function Register_FL_Rosetta_Random_Posts() {
	register_widget( 'FL_Rosetta_Random_Posts' );
}

add_action('widgets_init', 'Register_FL_Rosetta_Random_Posts');