<?php
///////////////////////
// Sharing Icons
///////////////////////

// Add/Edit Socials
function fl_rosetta_sharing() {
?>
	<div class="fl-sharing">
	    <span class="fl-stories"><?php esc_html_e( 'Share', 'flatlayers' ); ?></span>
	    <a class="twitter" href="https://twitter.com/home?status=<?php echo urlencode(get_the_title()); ?>-<?php the_permalink(); ?>" title="<?php esc_attr_e( 'Tweet This!', 'flatlayers' ); ?>" target="_blank" rel="noreferrer">
	        <i class="bi bi-twitter"></i>
	        <span><?php esc_html_e( 'Twitter', 'flatlayers' ); ?></span>
	    </a>
	    <a class="facebook" href="https://www.facebook.com/sharer.php?u=<?php the_permalink();?>" title="<?php esc_attr_e( 'Share on Facebook', 'flatlayers' ); ?>" target="_blank" rel="noreferrer">
	        <i class="bi bi-facebook"></i>
	        <span><?php esc_html_e( 'Facebook', 'flatlayers' ); ?></span>
	    </a>
	    <a class="linkedin" href="https://www.linkedin.com/sharing/share-offsite/?url=<?php the_permalink(); ?>" title="<?php esc_attr_e( 'Share on LinkedIn', 'flatlayers' ); ?>" target="_blank" rel="noreferrer">
	        <i class="bi bi-linkedin"></i>
	        <span><?php esc_html_e( 'LinkedIn', 'flatlayers' ); ?></span>
	    </a>
	    <a class="pinterest" href="https://pinterest.com/pin/create/button/?url=<?php the_permalink(); ?>&amp;media=<?php echo wp_get_attachment_url( get_post_thumbnail_id() ); ?>" title="<?php esc_attr_e( 'Pin this!', 'flatlayers' ); ?>" target="_blank" rel="noreferrer">
	        <i class="bi bi-pinterest"></i>
	        <span><?php esc_html_e( 'Pinterest', 'flatlayers' ); ?></span>
	    </a>
	    <a class="reddit" href="http://www.reddit.com/submit?url=<?php the_permalink(); ?>&amp;title=<?php echo urlencode(get_the_title()); ?>" title="<?php esc_attr_e( 'Share on Reddit', 'flatlayers' ); ?>" target="_blank" rel="noreferrer">
	        <i class="bi bi-reddit"></i>
	        <span><?php esc_html_e( 'Reddit', 'flatlayers' ); ?></span>
	    </a>
	</div>
<?php
}